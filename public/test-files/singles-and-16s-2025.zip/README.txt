Test bundle - replace with real zip for full testing
